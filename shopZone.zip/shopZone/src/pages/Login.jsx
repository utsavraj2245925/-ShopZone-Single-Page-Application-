import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = () => {
    login();
    navigate("/checkout");
  };

  return (
    <div className="container">
      <h2>Login</h2>
      <button className="btn" onClick={handleLogin}>
        Login as Guest
      </button>
    </div>
  );
};

export default Login;