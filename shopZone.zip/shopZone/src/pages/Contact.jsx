const Contact = () => {
  return (
    <div className="container">
      <h2>Contact Us</h2>
      <input placeholder="Your Name" />
      <input placeholder="Email" />
      <textarea placeholder="Message"></textarea>
      <button className="btn">Submit</button>
    </div>
  );
};

export default Contact;