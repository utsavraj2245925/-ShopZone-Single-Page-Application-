const Home = () => {
  return (
    <div className="container">
      <h1>Welcome to ShopZone 🛒</h1>
      <p>Your one stop shop for amazing products!</p>
    </div>
  );
};

export default Home;