import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { Link } from "react-router-dom";

const Cart = () => {
  const { cart, removeFromCart, totalPrice } = useContext(CartContext);

  return (
    <div className="container">
      <h2>Your Cart</h2>
      {cart.map((item, index) => (
        <div key={index} className="card">
          <h4>{item.title}</h4>
          <p>${item.price}</p>
          <button
            className="btn btn-danger"
            onClick={() => removeFromCart(index)}
          >
            Remove
          </button>
        </div>
      ))}
      <h3>Total: ${totalPrice}</h3>
      <Link to="/checkout">
        <button className="btn">Proceed to Checkout</button>
      </Link>
    </div>
  );
};

export default Cart;