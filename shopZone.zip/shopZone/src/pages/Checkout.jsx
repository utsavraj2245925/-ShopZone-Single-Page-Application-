const Checkout = () => {
  return (
    <div className="container">
      <h2>Checkout Page ✅</h2>
      <p>Order placed successfully!</p>
    </div>
  );
};

export default Checkout;